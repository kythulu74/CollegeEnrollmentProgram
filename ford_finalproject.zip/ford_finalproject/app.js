/**
 * app.js
 * DO NOT ALTER THIS CODE
 */
require('dotenv').config();
const express = require('express');
const app = express();
const port = process.env.PORT || 3000; // Define the port to listen on
const session = require('express-session');
const path = require('path');

// Middleware for parsing request bodies as JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.set('views',path.join(__dirname,'views'));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true
}));

// Serve static files (e.g., stylesheets)
app.use(express.static(__dirname + '/public'));

// Import and use the users router
const userRouter = require('./routes/users');
app.use('/', userRouter);

// Import and use the students router
const studentRouter = require('./routes/students');
app.use('/', studentRouter);

// Import and use the students router
const courseRouter = require('./routes/courses');
app.use('/', courseRouter);

// Import and use the students router
const facultyRouter = require('./routes/facultys');
app.use('/', facultyRouter);

// Import and use the students router
const enrollmentRouter = require('./routes/enrollments');
app.use('/', enrollmentRouter);

// Start the server
app.listen(process.env.PORT, () => {
  console.log(`App started and running on port ${process.env.PORT}`);
});