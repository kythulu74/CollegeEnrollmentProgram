const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');

//get route for landingpage
router.get('/api/landing-page', async (req,res)=>{
    if (req.session.user){
        const user = req.session.user;
        res.render('landing-page', {user});
    }
    else{
        res.redirect('/api/auth/login');
    }
    
});

//get route for login
router.get('/api/auth/login', (req,res)=>{
    res.render('login');
});

//post route for login
router.post('/api/auth/login', async (req,res)=>{
    const { username, password } = req.body;
    try{
        const user = await User.getUserByUsername(username);
        if(!user){
            res.redirect('/api/auth/login');
        } else {
            bcrypt.compare(password,user.password,(err,result)=>{
                if(result){
                    req.session.user = user;
                    res.redirect('/api/landing-page');
                } else {
                    res.redirect('/api/auth/login');
                }
            });     
        }   
    } catch (err) {
        throw err;
    }
});

//get route to create a user
router.get('/api/auth/register',(req,res)=>{
    res.render('registration');
});

//post route to create a user
router.post('/api/auth/register', async (req,res)=>{
    const {username,password,role}=req.body;
    try{
        const newUser = new User(null,username,password,role);
        await newUser.addUser();
        res.redirect('/api/auth/login');
    } catch (err) {
        console.error('Error adding a user: ' + err.message);
        res.status(500).json({error: 'Failed to add user'});
    }
});


//get route to display all users view
router.get('/api/users', async (req,res) => {
    if (req.session.user){
        const user = req.session.user;
        if (user.role === 'admin'){
            try {
                const users = await User.getAllUsers();
                res.render('show-users',{ user, users });
            } catch (err) {
                console.error('Error fetching users: ' + err.message);
                res.status(500).json({error: 'Failed to fetch users'});
            }
        } else {
            console.log('Unauthorized attempt to access users made by: ' + user.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
    }
    else{
        res.redirect('/api/auth/login');
    }
});

//get route to add a new user view
router.get('/api/users/new', (req, res) => {
    if (req.session.user){
        const user = req.session.user;
        if (user.role === 'admin'){
            res.render('add-user');
        } else {
            console.log('Unauthorized attempt to access users made by: ' + user.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
});

//post route to create new users
router.post('/api/users', async (req,res) => {
    if (req.session.user){
        const user = req.session.user;
        if (user.role === 'admin'){
            const { username, password, role} = req.body;
            const newUser = new User(null, username, password, role);
            try{
                await newUser.addUser();
                res.redirect('/api/users');
            } catch (err) {
                console.error('Error adding a user: ' + err.message);
                res.status(500).json({error: 'Failed to add user'});
            }
        } else {
            console.log('Unauthorized attempt to access users made by: ' + user.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
    
});

//get route to update existing user
router.get('/api/users/edit/:user_id', async (req, res) => {
    if (req.session.user){
        const user = req.session.user;
        if (user.role === 'admin'){
            const userId = req.params.user_id;
            try{
                const user = await User.getUserByuser_id(userId);
                res.render('edit-user', { user });
            } catch (err) {
                console.error('Error fetching user: ' + err.message);
                res.status(500).json({error: 'Failed to fetch user'});
            }
        } else {
            console.log('Unauthorized attempt to access users made by: ' + user.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
        
    }else{
        res.redirect('/api/auth/login');
    }
});

//post route to update existing user
router.post('/api/users/update/:user_id', async (req, res) => {
    if (req.session.user){
        const user = req.session.user;
        if (user.role === 'admin'){
            const userId = req.params.user_id;
            const { username, password, role} = req.body;
            const updatedUser = new User(userId, username, password, role);
            try{
                await updatedUser.updateUser();
                res.redirect('/api/users');
            } catch (err) {
                console.error('Error updating user: ' + err.message);
                res.status(500).json({error: 'Failed to update user'});
            }
        } else {
            console.log('Unauthorized attempt to access users made by: ' + user.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//get route to delete user
router.get('/api/users/delete/:user_id', async (req, res) => {
    if(req.session.user){
        const userSes = req.session.user;
        if (userSes.role === 'admin'){
            const userID = req.params.user_id;
            const user = await User.getUserByuser_id(userID);
            res.render('delete-user',{user});
        } else {
            console.log('Unauthorized attempt to access users made by: ' + userSes.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//post route to delete User
router.post('/api/users/delete/:user_id', async (req, res) => {
    if(req.session.user){
        const user = req.session.user;
        if (user.role === 'admin'){
            const userID = req.params.user_id;
            try{
                await User.deleteUser(userID);
                res.redirect('/api/users');
            } catch (err) {
                console.error('Error deleting user: ' + err.message);
                res.status(500).json({error: 'Failed to delete user'});
            } 
        } else {
            console.log('Unauthorized attempt to access users made by: ' + user.username)
            res.status(500).json({error: 'Only admins may access Users'});
        }
        
    }else{
        res.redirect('/api/auth/login');
    }
});

//log out
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error ending session: ' + err.message);
            res.status(500).json({ error: 'Failed to logout' });
        } else {
            res.redirect('/api/auth/login'); 
        }
    });
});

module.exports = router;