const express = require('express');
const router = express.Router();
const Faculty = require('../models/Faculty');

//get route to display all facultys view
router.get('/api/faculty', async (req,res) => {
    if (req.session.user){
        const user = req.session.user;
        try {
            const faculty = await Faculty.getAllFaculty();
            res.render('show-faculty',{ user, faculty });
        } catch (err) {
            console.error('Error fetching facultys: ' + err.message);
            res.status(500).json({error: 'Failed to fetch faculty'});
        }
    }
    else{
        res.redirect('/api/auth/login');
    }
});

//get route to add a new faculty view
router.get('/api/faculty/new', (req, res) => {
    if (req.session.user){
        res.render('add-faculty');
    }else {
        res.redirect('/api/auth/login');
    }
});

//post route to create new facultys
router.post('/api/faculty', async (req,res) => {
    if (req.session.user){
        const {first_name, last_name, email} = req.body;
        const newFaculty = new Faculty(null, first_name, last_name, email);
        try{
            await newFaculty.addFaculty();
            res.redirect('/api/faculty');
        } catch (err) {
            console.error('Error adding a faculty: ' + err.message);
            res.status(500).json({error: 'Failed to add faculty'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
    
});

//get route to update existing faculty
router.get('/api/faculty/edit/:faculty_id', async (req, res) => {
    if (req.session.user){
        const facultyId = req.params.faculty_id;
        try{
            const faculty = await Faculty.getfacultyByFacultyId(facultyId);
            res.render('edit-faculty', { faculty });
        } catch (err) {
            console.error('Error fetching faculty: ' + err.message);
            res.status(500).json({error: 'Failed to fetch faculty'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//post route to update existing faculty
router.post('/api/faculty/update/:faculty_id', async (req, res) => {
    if (req.session.user){
        const facultyId = req.params.faculty_id;
        const {first_name, last_name, email} = req.body;
        const updatedFaculty = new Faculty(facultyId, first_name, last_name, email);
        try{
            await updatedFaculty.updateFaculty();
            res.redirect('/api/faculty');
        } catch (err) {
            console.error('Error updating faculty: ' + err.message);
            res.status(500).json({error: 'Failed to update faculty'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete device view
router.get('/api/faculty/delete/:faculty_id', async (req, res) => {
    if(req.session.user){
        const facultyId = req.params.faculty_id;
        const faculty = await Faculty.getfacultyByFacultyId(facultyId);
        res.render('delete-faculty',{faculty});
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete device
router.post('/api/faculty/delete/:faculty_id', async (req, res) => {
    if(req.session.user){
        const facultyId = req.params.faculty_id;
        try{
            await Faculty.deleteFaculty(facultyId);
            res.redirect('/api/faculty');
        } catch (err) {
            console.error('Error deleting faculty: ' + err.message);
            res.status(500).json({error: 'Failed to delete faculty, please make sure teacher is unassigned from all classes before deleting'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

module.exports = router;