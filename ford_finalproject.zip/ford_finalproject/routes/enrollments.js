const express = require('express');
const router = express.Router();
const Enrollment = require('../models/Enrollment');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Course = require('../models/Course');

//get route to display all enrollments view
router.get('/api/enrollments', async (req,res) => {
    if (req.session.user){
        const user = req.session.user;
        try {
            const enrollments = await Enrollment.getAllEnrollments();
            const names = await Enrollment.getStudentsFacultyCoursesFromEnrollments(enrollments);
            res.render('show-enrollments',{ user, names });
        } catch (err) {
            console.error('Error fetching enrollments: ' + err.message);
            res.status(500).json({error: 'Failed to fetch enrollments'});
        }
    }
    else{
        res.redirect('/api/auth/login');
    }
});

//get route to add a new enrollment view
router.get('/api/enrollments/new/student', async (req, res) => {
    if (req.session.user){
        try {
            const students = await Student.getAllStudents();
            const courses = await Course.getAllCourses();
            res.render('add-student-enrollment',{students, courses});
        } catch (err) {
            console.error('Error fetching students and courses: ' + err.message);
            res.status(500).json({error: 'Failed to fetch students and courses'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
});

//get route to add a new enrollment view
router.get('/api/enrollments/new/faculty', async (req, res) => {
    if (req.session.user){
        try {
            const facultys = await Faculty.getAllFaculty();
            const courses = await Course.getAllCourses();
            res.render('add-faculty-enrollment',{facultys, courses});
        } catch (err) {
            console.error('Error fetching faculty and courses: ' + err.message);
            res.status(500).json({error: 'Failed to fetch faculty and courses'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
});

//post route to create new student enrollments
router.post('/api/enrollments/student', async (req,res) => {
    if (req.session.user){
        const {student_id, course_id} = req.body;
        const enrollmentExists = await Enrollment.checkStudentEnrollment(student_id,course_id);
        if (enrollmentExists){
            res.status(500).json({error: 'Student already enrolled in this course'});
        } else {
            const newEnrollment = new Enrollment(null, student_id, null, course_id);
            try{
                await newEnrollment.addEnrollment();
                res.redirect('/api/enrollments');
            } catch (err) {
                console.error('Error adding a enrollment: ' + err.message);
                res.status(500).json({error: 'Failed to add enrollment'});
            }
        }
    }else {
        res.redirect('/api/auth/login');
    }
});

//post route to create new faculty enrollments
router.post('/api/enrollments/faculty', async (req,res) => {
    if (req.session.user){
        const {faculty_id, course_id} = req.body;
        const enrollmentExists = await Enrollment.checkFacultyEnrollment(faculty_id,course_id);
        if (enrollmentExists){
            res.status(500).json({error: 'Faculty already assigned to this course'});
        } else {
            const newEnrollment = new Enrollment(null, null, faculty_id, course_id);
            try{
                await newEnrollment.addEnrollment();
                res.redirect('/api/enrollments');
            } catch (err) {
                console.error('Error adding a enrollment: ' + err.message);
                res.status(500).json({error: 'Failed to add enrollment'});
            }
        }
    }else {
        res.redirect('/api/auth/login');
    }
});

//delete student enrollment view
router.get('/api/enrollments/delete/student/:enrollment_id', async (req, res) => {
    if(req.session.user){
        const enrollmentId = req.params.enrollment_id;
        const enrollment = await Enrollment.getEnrollmentByEnrollmentId(enrollmentId);
        const student = await Student.getStudentBystudent_id(enrollment.student_id);
        const course = await Course.getCourseByCourseID(enrollment.course_id);
        res.render('delete-student-enrollment',{enrollment,student,course});
    }else{
        res.redirect('/api/auth/login');
    }
});


//delete student enrollment
router.post('/api/enrollments/delete/student/:enrollment_id', async (req, res) => {
    if(req.session.user){
        const enrollmentId = req.params.enrollment_id;
        const enrollment = await Enrollment.getEnrollmentByEnrollmentId(enrollmentId);
        try{
            await Enrollment.deleteEnrollment(enrollmentId);
            res.redirect('/api/enrollments');
        } catch (err) {
            console.error('Error deleting enrollment: ' + err.message);
            res.status(500).json({error: 'Failed to delete enrollment'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete faculty enrollment view
router.get('/api/enrollments/delete/faculty/:enrollment_id', async (req, res) => {
    if(req.session.user){
        const enrollmentId = req.params.enrollment_id;
        const enrollment = await Enrollment.getEnrollmentByEnrollmentId(enrollmentId);
        const faculty = await Faculty.getfacultyByFacultyId(enrollment.faculty_id);
        const course = await Course.getCourseByCourseID(enrollment.course_id);
        res.render('delete-faculty-enrollment',{enrollment,faculty,course});
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete faculty enrollment
router.post('/api/enrollments/delete/faculty/:enrollment_id', async (req, res) => {
    if(req.session.user){
        const enrollmentId = req.params.enrollment_id;
        const enrollment = await Enrollment.getEnrollmentByEnrollmentId(enrollmentId);
        try{
            await Enrollment.deleteEnrollment(enrollmentId);
            res.redirect('/api/enrollments');
        } catch (err) {
            console.error('Error deleting enrollment: ' + err.message);
            res.status(500).json({error: 'Failed to delete enrollment'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

module.exports = router;