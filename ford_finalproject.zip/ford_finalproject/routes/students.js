const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

//get route to display all students view
router.get('/api/students', async (req,res) => {
    if (req.session.user){
        const user = req.session.user;
        try {
            const students = await Student.getAllStudents();
            res.render('show-students',{ user, students });
        } catch (err) {
            console.error('Error fetching students: ' + err.message);
            res.status(500).json({error: 'Failed to fetch students'});
        }
    }
    else{
        res.redirect('/api/auth/login');
    }
});

//get route to add a new Student view
router.get('/api/students/new', (req, res) => {
    if (req.session.user){
        res.render('add-student');
    }else {
        res.redirect('/api/auth/login');
    }
});

//post route to create new students
router.post('/api/students', async (req,res) => {
    if (req.session.user){
        const {first_name, last_name, email} = req.body;
        const newStudent = new Student(null, first_name, last_name, email);
        try{
            await newStudent.addStudent();
            res.redirect('/api/students');
        } catch (err) {
            console.error('Error adding a Student: ' + err.message);
            res.status(500).json({error: 'Failed to add Student'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
    
});

//get route to update existing Student
router.get('/api/students/edit/:student_id', async (req, res) => {
    if (req.session.user){
        const studentId = req.params.student_id;
        try{
            const student = await Student.getStudentBystudent_id(studentId);
            res.render('edit-Student', { student });
        } catch (err) {
            console.error('Error fetching Student: ' + err.message);
            res.status(500).json({error: 'Failed to fetch Student'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//post route to update existing Student
router.post('/api/students/update/:student_id', async (req, res) => {
    if (req.session.user){
        const studentId = req.params.student_id;
        const {first_name, last_name, email} = req.body;
        const updatedStudent = new Student(studentId, first_name, last_name, email);
        try{
            await updatedStudent.updateStudent();
            res.redirect('/api/students');
        } catch (err) {
            console.error('Error updating Student: ' + err.message);
            res.status(500).json({error: 'Failed to update Student'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete student view
router.get('/api/students/delete/:student_id', async (req, res) => {
    if(req.session.user){
        const studentId = req.params.student_id;
        const student = await Student.getStudentBystudent_id(studentId);
        res.render('delete-student',{student});
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete student
router.post('/api/students/delete/:student_id', async (req, res) => {
    if(req.session.user){
        const studentId = req.params.student_id;
        try{
            await Student.deleteStudent(studentId);
            res.redirect('/api/students');
        } catch (err) {
            console.error('Error deleting Student: ' + err.message);
            res.status(500).json({error: 'Failed to delete Student, please make sure student in unerolled from all classes before deleting'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

module.exports = router;