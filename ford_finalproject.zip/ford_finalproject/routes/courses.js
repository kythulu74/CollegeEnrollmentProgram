const express = require('express');
const router = express.Router();
const Course = require('../models/Course');

//get route to display all courses view
router.get('/api/courses', async (req,res) => {
    if (req.session.user){
        const user = req.session.user;
        try {
            const courses = await Course.getAllCourses();
            res.render('show-courses',{ user, courses });
        } catch (err) {
            console.error('Error fetching courses: ' + err.message);
            res.status(500).json({error: 'Failed to fetch courses'});
        }
    }
    else{
        res.redirect('/api/auth/login');
    }
});

//get route to add a new course view
router.get('/api/courses/new', (req, res) => {
    if (req.session.user){
        res.render('add-course');
    }else {
        res.redirect('/api/auth/login');
    }
});

//post route to create new courses
router.post('/api/courses', async (req,res) => {
    if (req.session.user){
        const {course_name, credits} = req.body;
        const newCourse = new Course(null, course_name, credits);
        try{
            await newCourse.addCourse();
            res.redirect('/api/courses');
        } catch (err) {
            console.error('Error adding a course: ' + err.message);
            res.status(500).json({error: 'Failed to add course'});
        }
    }else {
        res.redirect('/api/auth/login');
    }
    
});

//get route to update existing course
router.get('/api/courses/edit/:course_id', async (req, res) => {
    if (req.session.user){
        const courseId = req.params.course_id;
        try{
            const course = await Course.getCourseByCourseID(courseId);
            res.render('edit-course', { course });
        } catch (err) {
            console.error('Error fetching course: ' + err.message);
            res.status(500).json({error: 'Failed to fetch course'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//post route to update existing course
router.post('/api/courses/update/:course_id', async (req, res) => {
    if (req.session.user){
        const courseId = req.params.course_id;
        const {course_name, credits} = req.body;
        const updatedCourse = new Course(courseId, course_name, credits);
        try{
            await updatedCourse.updateCourse();
            res.redirect('/api/courses');
        } catch (err) {
            console.error('Error updating course: ' + err.message);
            res.status(500).json({error: 'Failed to update course'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete course view
router.get('/api/courses/delete/:course_id', async (req, res) => {
    if(req.session.user){
        const courseId = req.params.course_id;
        const course = await Course.getCourseByCourseID(courseId);
        res.render('delete-course',{course});
    }else{
        res.redirect('/api/auth/login');
    }
});

//delete course
router.post('/api/courses/delete/:course_id', async (req, res) => {
    if(req.session.user){
        const courseId = req.params.course_id;
        try{
            await Course.deleteCourse(courseId);
            res.redirect('/api/courses');
        } catch (err) {
            console.error('Error deleting course: ' + err.message);
            res.status(500).json({error: 'Failed to delete course, please ensure no students or faculty are assigned to this course before deleting'});
        }
    }else{
        res.redirect('/api/auth/login');
    }
});

module.exports = router;