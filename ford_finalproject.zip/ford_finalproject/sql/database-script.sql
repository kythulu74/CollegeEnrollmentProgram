CREATE DATABASE IF NOT EXISTS college;

USE college;

CREATE TABLE IF NOT EXISTS users (
	user_id INT PRIMARY KEY auto_increment,
    username varchar(50) UNIQUE NOT NULL,
    password varchar(255) UNIQUE NOT NULL,
    role ENUM('admin','staff') NOT NULL);

CREATE TABLE IF NOT EXISTS students (
	student_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL);
    
CREATE TABLE IF NOT EXISTS courses(
	course_id INT PRIMARY KEY auto_increment,
    course_name VARCHAR(100) NOT NULL,
    credits INT NOT NULL);
    
CREATE TABLE IF NOT EXISTS faculty (
	faculty_id INT PRIMARY KEY auto_increment,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL);
    
CREATE TABLE IF NOT EXISTS enrollments (
	enrollment_id INT PRIMARY KEY auto_increment,
    student_id INT,
    faculty_id INT,
    course_id INT,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id));