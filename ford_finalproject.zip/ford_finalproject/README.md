# Enrollment Management System

## Description
- The Enrollment Management System is a program that allows users to create, view, edit, and delete college students, faculty, courses, and enrollments. It is designed to efficiently manage enrollments for a college.

## System Requirements
- Node.js: You must have Node.js installed. You may download and install Node.js at "https://nodejs.org". Ensure you have version 20.8.0
- MySQL: You must have MySQL installed. You may download and install MySQL at "https://www.mysql.com".
- Express.js: This will automatically install when "npm install" is run in installation and setup.

## Installation and Set Up

- Create the Database
- 1. Open MySQL command line or MySQL workbench
- 2. Create a new database using command "CREATE DATABASE IF NOT EXISTS college;" located in database-script.sql file
- 3. Use the database with command "USE college;" located in database-script.sql file.
- 4. Create the students, courses, faculty, and enrollments tables using the commands located in the database-script.sql files
- 5. Ensure creation of these tables using "SHOW TABLES;" command

- Edit .env File
- 1. Locate the .env file in the file directory
- 2. Open the .env file in a text editor of your choice
- 3. Update the DB_HOST, DB_USER, and DB_PASSWORD to match your environment
- 4. Save the changes you have made

- Install Dependencies
- 1. Navigate to program directory using command "cd /path" replacing "/path" with the path to the program
- 2. Once in directory run command "npm install" to install necessary dependencies listed in package.json file.
- 3. Verify folder node_modules is created in program directory

- Run application
- 1. Navigate to program directory using command "cd /path" replacing "/path" with the path to the program
- 2. Run command "node app" to start the program
- 3. Verify in the terminal App started and running on port 3000
- 4. Open browser and navigate to address "http://localhost:3000/api/auth/login" to start managing enrollments

## Usage

http://localhost:3000/api/auth/login
- This page allows users to login using there username and password
- This page also contains a link to take new users to a registration page

http://localhost:3000/api/auth/register
- This page allows new users to create a username and password for login. New users must also select a role, either "admin" or "staff". Admins will be granted access to users page once logged in.
- Once a new user registers they will be directed back to the login page.

http://localhost:3000/api/landing-page
- This page serves as a home page, it contains the links to students, courses, faculty, and enrollments pages as well as the users page for admins and a link to logout.

http://localhost:3000/api/users
- This page allows the user to add, edit, view, and delete users

http://localhost:3000/api/students
- This page allows the user to add, edit, view, and delete students

http://localhost:3000/api/courses
- This page allows the user to add, edit, view, and delete courses

http://localhost:3000/api/faculty
- This page allows the user to add, edit, view, and delete faculty members

http://localhost:3000/api/enrollments
- This page allows the user to add, edit, view, and delete enrollments
