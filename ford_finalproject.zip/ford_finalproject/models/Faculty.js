const db = require('../database');

class Faculty {
    constructor(faculty_id, first_name, last_name, email){
        this.faculty_id=faculty_id;
        this.first_name=first_name;
        this.last_name=last_name;
        this.email=email;
    }

    //retrieve all facultys
    static async getAllFaculty(){
        const query = 'SELECT * FROM faculty';
        try{
            const [results] = await db.execute(query);
            return results;
        } catch (err) {
            throw err;
        }
    }

    //method to add faculty
    async addFaculty(){
        const {first_name,last_name,email} =this;
        const query = 'INSERT INTO faculty (first_name, last_name, email) VALUES (?, ?, ?)';
        try{
            await db.execute(query, [first_name, last_name, email]);
        } catch (err) {
            throw err;
        }
    }

    //find faculty by faculty_id
    static async getfacultyByFacultyId(faculty_id){
        const query = 'SELECT * FROM faculty WHERE faculty_id = ?';
        try{
            const [results] =await db.execute(query, [faculty_id]);
            if (results.length === 0 ){
                throw 'faculty memeber not found';
            }
            return results[0];
        } catch (err){
            throw err;
        }
    }

    //update faculty
    async updateFaculty(){
        const {faculty_id, first_name, last_name, email} = this;
        const query = 'UPDATE faculty SET first_name = ?, last_name = ?, email = ? WHERE faculty_id = ?';
        try{
            const [results] = await db.execute(query, [first_name, last_name, email, faculty_id]);
            if (results.affectedRows === 0 ){
                throw 'faculty member not found';
            }
        }catch (err) {
            throw err;
        }
    }

    //delete faculty
    static async deleteFaculty(faculty_id) {
        const query = 'DELETE FROM faculty WHERE faculty_id = ?';
        try{
            const [results] = await db.execute(query,[faculty_id]);
            if (results.affectedRows === 0){
                throw 'faculty member not found';
            }
        } catch (err){
            throw err;
        }
    }
}

module.exports = Faculty;