const db = require('../database');
const bcrypt = require('bcrypt');

class User {
    constructor(user_id, username, password,role){
        this.user_id=user_id;
        this.username=username;
        this.password=password;
        this.role=role;
    }

    //method to create User
    async addUser(){
        const {username,password,role} = this;
        const query = 'INSERT INTO users (username, password, role) VALUES (?, ?, ?)';
        try{
            const hashedPassword = await bcrypt.hash(password,10);
            await db.execute(query, [username,hashedPassword,role]);
        } catch {
            throw error;
        }
    }

    //retrieve all Users
    static async getAllUsers(){
        const query = 'SELECT * FROM users';
        try{
            const [results] = await db.execute(query);
            return results;
        } catch (err) {
            throw err;
        }
    }

    //find User by user_id
    static async getUserByuser_id(user_id){
        const query = 'SELECT * FROM users WHERE user_id = ?';
        try{
            const [results] =await db.execute(query, [user_id]);
            if (results.length === 0 ){
                return results[0];
            }
            return results[0];
        } catch (err){
            throw err;
        }
    }

    //find User by username
    static async getUserByUsername(username){
        const query = 'SELECT * FROM users WHERE username = ?';
        try{
            const [results] = await db.execute(query, [username]);
            if (results.length === 0 ){
                return results[0];
            }
            return results[0];
        } catch (err){
            throw err;
        }
    }

    //update User
    async updateUser(){
        const {user_id, username, password, role} = this;
        const query = 'UPDATE users SET username = ?, password = ?, role = ? WHERE user_id = ?';
        try{
            const hashedPassword = await bcrypt.hash(password,10);
            const [results] = await db.execute(query,[username,hashedPassword,role, user_id]);
            if (results.affectedRows === 0 ){
                throw 'User not found';
            }
        } catch {
            throw error;
        }
    }

    //delete User
    static async deleteUser(user_id) {
        const query = 'DELETE FROM users WHERE user_id = ?';
        try{
            const [results] = await db.execute(query,[user_id]);
            if (results.affectedRows === 0){
                throw 'User not found';
            }
        } catch (err){
            throw err;
        }
    }
}

module.exports = User;