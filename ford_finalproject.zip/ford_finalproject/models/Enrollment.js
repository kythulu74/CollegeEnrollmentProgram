const db = require('../database');
const Student = require('../models/Student');
const Faculty = require('../models/Faculty');
const Course = require('../models/Course');

class Enrollment {
    constructor(enrollment_id, student_id, faculty_id, course_id){
        this.enrollment_id=enrollment_id;
        this.student_id=student_id;
        this.faculty_id=faculty_id;
        this.course_id=course_id;
    }

    //retrieve all enrollments
    static async getAllEnrollments(){
        const query = 'SELECT * FROM enrollments';
        try{
            const [results] = await db.execute(query);
            return results;
        } catch (err) {
            throw err;
        }
    }

    //
    static async getStudentsFacultyCoursesFromEnrollments(enrollments){
        const result = [];
        for(const enrollment of enrollments){
            if (enrollment.student_id === null){
                const fac = await Faculty.getfacultyByFacultyId(enrollment.faculty_id);
                const cor = await Course.getCourseByCourseID(enrollment.course_id)
                const faculty_name = fac.first_name + " " + fac.last_name;
                const course_name = cor.course_name;
                const enroll_id = enrollment.enrollment_id;
                const studentID = null;
                const facultyID = fac.faculty_id;
                const courseID = cor.course_id;
                const student_name = null;
                const enrollData = {
                    enrollment_id: enroll_id,
                    student_id: studentID,
                    studentName: student_name,
                    faculty_id: facultyID,
                    facultyName: faculty_name,
                    course_id: courseID,
                    courseName: course_name, 
                };
                result.push(enrollData);
            } else {
                const stu = await Student.getStudentBystudent_id(enrollment.student_id);
                const cor = await Course.getCourseByCourseID(enrollment.course_id)
                const student_name = stu.first_name + " " + stu.last_name;
                const course_name = cor.course_name;
                const enroll_id = enrollment.enrollment_id;
                const studentID = stu.student_id;
                const facultyID = null;
                const courseID = cor.course_id;
                const faculty_name = null;
                const enrollData = {
                    enrollment_id: enroll_id,
                    student_id: studentID,
                    studentName: student_name,
                    faculty_id: facultyID,
                    facultyName: faculty_name,
                    course_id: courseID,
                    courseName: course_name, 
                };
                result.push(enrollData);
            }
        }
        return result;
    }

    //method to add enrollment
    async addEnrollment(){
        const {student_id,faculty_id,course_id} =this;
        const query = 'INSERT INTO enrollments (student_id, faculty_id, course_id) VALUES (?, ?, ?)';
        try{
            await db.execute(query, [student_id, faculty_id, course_id]);
        } catch (err) {
            throw err;
        }
    }

    //find enrollment by enrollment_id
    static async getEnrollmentByEnrollmentId(enrollment_id){
        const query = 'SELECT * FROM enrollments WHERE enrollment_id = ?';
        try{
            const [results] =await db.execute(query, [enrollment_id]);
            if (results.length === 0 ){
                throw 'enrollment not found';
            }
            return results[0];
        } catch (err){
            throw err;
        }
    }

    //delete enrollment
    static async deleteEnrollment(enrollment_id) {
        const query = 'DELETE FROM enrollments WHERE enrollment_id = ?';
        try{
            const [results] = await db.execute(query,[enrollment_id]);
            if (results.affectedRows === 0){
                throw 'enrollment not found';
            }
        } catch (err){
            throw err;
        }
    }

    //check student enrollment
    static async checkStudentEnrollment(student_id,course_id){
        const query = 'SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?';
        const [enrollments] = await db.execute(query, [student_id, course_id]);
        return enrollments.length > 0;
    }

    //check faculty enrollment
    static async checkFacultyEnrollment(faculty_id,course_id){
        const query = 'SELECT * FROM enrollments WHERE faculty_id = ? AND course_id = ?';
        const [enrollment] = await db.execute(query, [faculty_id, course_id]);
        return enrollment.length > 0;
    }
}

module.exports = Enrollment;