const db = require('../database');

class Student {
    constructor(student_id, first_name, last_name, email){
        this.student_id=student_id;
        this.first_name=first_name;
        this.last_name=last_name;
        this.email=email;
    }

    //retrieve all Students
    static async getAllStudents(){
        const query = 'SELECT * FROM students';
        try{
            const [results] = await db.execute(query);
            return results;
        } catch (err) {
            throw err;
        }
    }

    //method to add Student
    async addStudent(){
        const {first_name,last_name,email} =this;
        const query = 'INSERT INTO students (first_name, last_name, email) VALUES (?, ?, ?)';
        try{
            await db.execute(query, [first_name, last_name, email]);
        } catch (err) {
            throw err;
        }
    }

    //find Student by student_id
    static async getStudentBystudent_id(student_id){
        const query = 'SELECT * FROM students WHERE student_id = ?';
        try{
            const [results] =await db.execute(query, [student_id]);
            if (results.length === 0 ){
                throw 'Student not found';
            }
            return results[0];
        } catch (err){
            throw err;
        }
    }

    //update Student
    async updateStudent(){
        const {student_id, first_name, last_name, email} = this;
        const query = 'UPDATE students SET first_name = ?, last_name = ?, email = ? WHERE student_id = ?';
        try{
            const [results] = await db.execute(query, [first_name, last_name, email, student_id]);
            if (results.affectedRows === 0 ){
                throw 'Student not found';
            }
        }catch (err) {
            throw err;
        }
    }

    //delete Student
    static async deleteStudent(student_id) {
        const query = 'DELETE FROM students WHERE student_id = ?';
        try{
            const [results] = await db.execute(query,[student_id]);
            if (results.affectedRows === 0){
                throw 'Student not found';
            }
        } catch (err){
            throw err;
        }
    }
}

module.exports = Student;