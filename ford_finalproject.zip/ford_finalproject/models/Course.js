const db = require('../database');

class Course {
    constructor(course_id, course_name, credits){
        this.course_id=course_id;
        this.course_name=course_name;
        this.credits=credits;
    }

    //retrieve all courses
    static async getAllCourses(){
        const query = 'SELECT * FROM courses';
        try{
            const [results] = await db.execute(query);
            return results;
        } catch (err) {
            throw err;
        }
    }

    //method to add course
    async addCourse(){
        const {course_name,credits} =this;
        const query = 'INSERT INTO courses (course_name, credits) VALUES (?, ?)';
        try{
            await db.execute(query, [course_name, credits]);
        } catch (err) {
            throw err;
        }
    }

    //find course by course_id
    static async getCourseByCourseID(course_id){
        const query = 'SELECT * FROM courses WHERE course_id = ?';
        try{
            const [results] =await db.execute(query, [course_id]);
            if (results.length === 0 ){
                throw 'course not found';
            }
            return results[0];
        } catch (err){
            throw err;
        }
    }

    //update course
    async updateCourse(){
        const {course_id, course_name, credits} = this;
        const query = 'UPDATE courses SET course_name = ?, credits = ? WHERE course_id = ?';
        try{
            const [results] = await db.execute(query, [course_name, credits, course_id]);
            if (results.affectedRows === 0 ){
                throw 'course not found';
            }
        }catch (err) {
            throw err;
        }
    }

    //delete course
    static async deleteCourse(course_id) {
        const query = 'DELETE FROM courses WHERE course_id = ?';
        try{
            const [results] = await db.execute(query,[course_id]);
            if (results.affectedRows === 0){
                throw 'course not found';
            }
        } catch (err){
            throw err;
        }
    }
}

module.exports = Course;